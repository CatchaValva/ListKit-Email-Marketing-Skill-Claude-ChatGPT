"""Self-hosted business outreach worker."""
import argparse
import contextlib
import email
import email.policy
import imaplib
import ipaddress
import json
import os
import re
import smtplib
import socket
import sqlite3
import ssl
import time
from datetime import datetime, timezone
from email.message import EmailMessage
from email.utils import make_msgid, parseaddr
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

ADDRESS = re.compile(r"[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+")
ROLE = re.compile(r"(?i)^(info|contact|hello|office|sales|enquiries|inquiries|reception|business|partnerships|admin)(?:[._-].+)?$")
MESSAGE_ID = re.compile(r"<[^<>\s]+>")
SCHEMA = """
CREATE TABLE IF NOT EXISTS leads(
 id INTEGER PRIMARY KEY, email TEXT UNIQUE, company TEXT, source TEXT,
 mx TEXT, approved INTEGER DEFAULT 0, suppressed INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS deliveries(
 campaign TEXT, lead INTEGER, mid TEXT UNIQUE, day TEXT, state TEXT,
 PRIMARY KEY(campaign, lead));
CREATE TABLE IF NOT EXISTS replies(
 mailbox TEXT, validity TEXT, uid TEXT, mid TEXT, campaign TEXT, sender TEXT,
 subject TEXT, body TEXT, classification TEXT, forwarding TEXT, destination TEXT,
 PRIMARY KEY(mailbox, validity, uid));
"""


class ContactPage(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.addresses = set()

    def handle_starttag(self, tag, attrs):
        href = dict(attrs).get("href") or ""
        if tag == "a":
            self.links.append(href)
            if href.lower().startswith("mailto:"):
                self.collect(href[7:].split("?")[0])

    def handle_data(self, data):
        self.collect(data)

    def collect(self, data):
        self.addresses.update(value.lower() for value in ADDRESS.findall(data))


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def fetch(url, data=None):
    parsed = urlsplit(url)
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username
            or parsed.password or parsed.port not in (None, 443)):
        raise ValueError("Expected a public HTTPS website")
    answers = socket.getaddrinfo(parsed.hostname, 443, type=socket.SOCK_STREAM)
    if not all(ipaddress.ip_address(item[4][0]).is_global for item in answers):
        raise ValueError("Website did not resolve to public IP addresses")
    request = Request(url, data=data, headers={"User-Agent": "LeadnClose/1.0 (business contact discovery)"})
    with build_opener(NoRedirect()).open(request, timeout=12) as response:
        return response.read(1_000_000).decode("utf-8", errors="replace")


def businesses(search):
    bbox = [float(value) for value in search["bbox"]]
    if len(bbox) != 4 or not (-90 <= bbox[0] < bbox[2] <= 90 and -180 <= bbox[1] < bbox[3] <= 180):
        raise ValueError("Use a south, west, north, east bounding box")
    key, value = search["tag"].split("=", 1)
    if not all(re.fullmatch(r"[a-z_]+", item) for item in (key, value)):
        raise ValueError("Use an exact OpenStreetMap tag such as healthcare=physiotherapist")
    limit = max(1, min(int(search.get("limit", 25)), 100))
    bounds = ",".join(map(str, bbox))
    query = f'[out:json][timeout:25];nwr["{key}"="{value}"]({bounds});out tags {limit};'
    payload = urlencode({"data": query}).encode()
    result = json.loads(fetch("https://overpass-api.de/api/interpreter", payload))
    keyword = search.get("keyword", "").casefold()
    for item in result["elements"]:
        tags = item.get("tags", {})
        name = tags.get("name", "")
        if keyword in name.casefold():
            yield (name, tags.get("contact:website") or tags.get("website"),
                   tags.get("contact:email") or tags.get("email", ""),
                   f"https://www.openstreetmap.org/{item['type']}/{item['id']}")


def website_contacts(website):
    root = urlsplit(website)
    origin = root.hostname
    home = ContactPage()
    home.feed(fetch(website))
    yield website, home.addresses
    links = dict.fromkeys(urljoin(website, link) for link in home.links
                          if "contact" in urlsplit(link).path.lower())
    same_site = [link for link in links if urlsplit(link).hostname == origin and link != website]
    for link in same_site[:2]:
        try:
            page = ContactPage()
            page.feed(fetch(link))
            yield link, page.addresses
        except (OSError, ValueError) as error:
            print(f"Contact page skipped: {error}")


def mx_status(address):
    import dns.exception
    import dns.resolver
    try:
        records = dns.resolver.resolve(address.rsplit("@", 1)[1], "MX", lifetime=5)
        return "domain-mx" if any(str(record.exchange) != "." for record in records) else "no-mx"
    except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
        return "no-mx"
    except dns.exception.DNSException:
        return "unconfirmed"


def discover(db, config):
    def sources():
        for website in config.get("websites", []):
            yield urlsplit(website).hostname, website, "", ""
        for search in config.get("searches", []):
            try:
                yield from businesses(search)
            except (OSError, ValueError, KeyError) as error:
                print(f"Directory search skipped: {error}")

    checked = {}
    count = 0
    for company, website, listed, source in sources():
        def pages():
            yield source, ADDRESS.findall(listed)
            if website:
                try:
                    yield from website_contacts(website)
                except (OSError, ValueError) as error:
                    print(f"Website skipped: {error}")

        for page, addresses in pages():
            for address in sorted(set(address.lower() for address in addresses)):
                if not ROLE.fullmatch(address.split("@")[0]):
                    continue
                domain = address.split("@")[1]
                if domain not in checked:
                    checked[domain] = mx_status(address)
                count += db.execute(
                    """INSERT INTO leads(email,company,source,mx) VALUES(?,?,?,?)
                    ON CONFLICT(email) DO UPDATE SET mx=excluded.mx WHERE mx != excluded.mx""",
                    (address, company or domain, page, checked[domain]),
                ).rowcount
        db.commit()
    print(f"Lead records added or refreshed: {count}")


def address(value):
    if not ADDRESS.fullmatch(value):
        raise ValueError(f"Expected a single email address: {value!r}")
    return value


def microsoft_token(config, interactive=False):
    import msal

    path = Path(config.get("microsoft_cache", ".microsoft-token-cache"))
    cache = msal.SerializableTokenCache()
    if path.exists():
        cache.deserialize(path.read_text(encoding="utf-8"))
    app = msal.PublicClientApplication(
        config["microsoft_client_id"],
        authority="https://login.microsoftonline.com/" + config.get("microsoft_tenant", "common"),
        token_cache=cache,
    )
    scopes = ["https://outlook.office.com/IMAP.AccessAsUser.All",
              "https://outlook.office.com/SMTP.Send"]
    accounts = app.get_accounts(username=config["username"])
    try:
        result = app.acquire_token_silent(scopes, account=accounts[0]) if accounts else None
        if interactive and not (result and "access_token" in result):
            flow = app.initiate_device_flow(scopes=scopes)
            if "message" not in flow:
                raise RuntimeError(flow.get("error_description", "Microsoft device login unavailable"))
            print(flow["message"], flush=True)
            result = app.acquire_token_by_device_flow(flow)
    finally:
        if cache.has_state_changed:
            temporary = path.with_name(path.name + ".tmp")
            with os.fdopen(os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600),
                           "w", encoding="utf-8") as file:
                file.write(cache.serialize())
            temporary.replace(path)
    if not result or "access_token" not in result or not app.get_accounts(username=config["username"]):
        raise RuntimeError("Run microsoft-login and sign in as the configured campaign mailbox")
    return result["access_token"]


def oauth_string(config):
    return f"user={config['username']}\x01auth=Bearer {microsoft_token(config)}\x01\x01"


def smtp_send(config, message):
    host = config["smtp_host"]
    port = int(config.get("smtp_port", 465))
    tls = ssl.create_default_context()
    if port == 465:
        connection = smtplib.SMTP_SSL(host, port, context=tls, timeout=20)
    else:
        connection = smtplib.SMTP(host, port, timeout=20)
    with connection as client:
        if port != 465:
            client.starttls(context=tls)
        if config.get("microsoft_client_id"):
            client.auth("XOAUTH2", lambda challenge=None: oauth_string(config) if challenge is None else "")
        else:
            client.login(config["username"], os.environ["LEADNCLOSE_MAIL_SECRET"])
        client.send_message(message)


def message_for(config, recipient, subject, body, mid):
    message = EmailMessage()
    message["From"] = address(config["from"])
    message["To"] = address(recipient)
    message["Subject"] = subject
    message["Message-ID"] = mid
    message.set_content(body)
    return message


def campaign_message(config, campaign, lead, mid):
    def render(template):
        return template.replace("{{company}}", lead["company"]).replace("{{email}}", lead["email"])
    body = render(campaign["body"])
    body += "\n\n" + config["sender_identity"] + "\n" + config["postal_address"]
    body += "\nTo stop receiving these emails, reply unsubscribe."
    return message_for(config, lead["email"], render(campaign["subject"]), body, mid)


def send_campaigns(db, config, live=False):
    day = datetime.now(timezone.utc).date().isoformat()
    campaigns = config.get("campaigns", [])
    names = [campaign["id"] for campaign in campaigns]
    if len(set(names)) != len(names):
        raise ValueError("Campaign IDs must be unique")
    remaining = max(0, int(config.get("daily_limit", 25)) - db.execute(
        "SELECT count(*) FROM deliveries WHERE day=?", (day,)
    ).fetchone()[0])
    for campaign in campaigns:
        if not campaign.get("enabled"):
            continue
        if campaign.get("start_at") and datetime.now(timezone.utc) < datetime.fromisoformat(campaign["start_at"]):
            continue
        leads = db.execute(
            """SELECT * FROM leads WHERE approved=1 AND suppressed=0 AND mx='domain-mx'
            AND company LIKE ? AND id NOT IN
            (SELECT lead FROM deliveries WHERE campaign=?) ORDER BY id""",
            ("%" + campaign.get("company_contains", "") + "%", campaign["id"]),
        ).fetchall()
        for lead in leads:
            if not remaining:
                return
            if campaign.get("lead_ids") is not None and lead["id"] not in campaign["lead_ids"]:
                continue
            mid = make_msgid(domain=config["from"].split("@")[1])
            message = campaign_message(config, campaign, lead, mid)
            if not live:
                remaining -= 1
                print(f"Preview {campaign['id']} → {lead['email']}: {message['Subject']}")
                continue
            claimed = db.execute("INSERT OR IGNORE INTO deliveries VALUES(?,?,?,?,?)",
                                 (campaign["id"], lead["id"], mid, day, "attempted")).rowcount
            db.commit()
            if not claimed:
                continue
            smtp_send(config, message)
            db.execute("UPDATE deliveries SET state='sent' WHERE mid=?", (mid,))
            db.commit()
            remaining -= 1


def extract_reply(message):
    part = message.get_body(preferencelist=("plain", "html"))
    if not part:
        return ""
    raw = part.get_content()
    if part.get_content_type() == "text/html":
        raw = re.split(r"<blockquote\b|<div[^>]*\b(?:gmail_quote|divRplyFwdMsg)\b", raw,
                       maxsplit=1, flags=re.I)[0]
        raw = re.sub(r"<(?:br|/p|/div)\b[^>]*>", "\n", raw, flags=re.I)
        from html import unescape
        raw = unescape(re.sub(r"<[^>]+>", "", raw))
    result = []
    for line in raw.splitlines():
        if re.match(r"\s*(>|On .+ wrote:|[- ]*Original Message[- ]*|From:\s)", line, re.I):
            break
        result.append(line)
    return "\n".join(result).strip()[:12000]


def classify(message, body):
    if (message.get_content_type() == "multipart/report"
            or message.get("Auto-Submitted", "no").lower() != "no"
            or re.search(r"out of office|automatic reply|delivery status notification",
                         str(message.get("Subject", "")), re.I)):
        return "automatic"
    if re.search(r"\bunsubscribe\b|\b(?:remove me|stop emailing|do not contact|take me off)\b", body, re.I):
        return "unsubscribe"
    if re.search(r"\b(?:not interested|no thanks|no thank you|not a fit|not right now|don't send)\b", body, re.I):
        return "negative"
    if re.search(r"^\s*yes[.!\s]*$|\b(?:i am interested|i'm interested|we are interested|we're interested|send (?:me |us )?(?:more )?(?:details|information)|book a (?:call|meeting)|schedule a (?:call|meeting)|what (?:are|is) your (?:rates|pricing))\b", body, re.I):
        return "positive"
    return "review"


def record_reply(db, config, mailbox, validity, uid, raw):
    message = email.message_from_bytes(raw, policy=email.policy.default)
    sender = parseaddr(str(message.get("From", "")))[1].lower()
    thread = MESSAGE_ID.findall(" ".join(str(message.get(key, "")) for key in ("In-Reply-To", "References")))
    if not thread:
        return
    placeholders = ",".join("?" for _ in thread)
    match = db.execute(
        f"""SELECT campaign, mid FROM deliveries JOIN leads ON leads.id=deliveries.lead
        WHERE email=? AND mid IN ({placeholders}) ORDER BY deliveries.rowid DESC LIMIT 1""",
        (sender, *thread),
    ).fetchone()
    if not match:
        return
    body = extract_reply(message)
    classification = classify(message, body)
    subject = str(message.get("Subject", ""))[:300]
    overrides = {campaign["id"]: campaign.get("forward_to") for campaign in config.get("campaigns", [])}
    destination = overrides.get(match["campaign"]) or config.get("forward_to")
    if classification == "unsubscribe":
        db.execute("UPDATE leads SET suppressed=1 WHERE email=?", (sender,))
    db.execute("INSERT OR IGNORE INTO replies VALUES(?,?,?,?,?,?,?,?,?,?,?)",
               (mailbox, validity, uid, match["mid"], match["campaign"], sender, subject, body,
                classification, "pending" if classification == "positive" and destination else "none",
                destination))
    db.commit()


def scan_inbox(db, config):
    mailbox = "INBOX"
    tls = ssl.create_default_context()
    account = f"{config['imap_host']}/{config['username']}/{mailbox}"
    with imaplib.IMAP4_SSL(config["imap_host"], int(config.get("imap_port", 993)),
                          ssl_context=tls, timeout=20) as client:
        if config.get("microsoft_client_id"):
            auth = oauth_string(config).encode()
            client.authenticate("XOAUTH2", lambda challenge: auth if not challenge else b"")
        else:
            client.login(config["username"], os.environ["LEADNCLOSE_MAIL_SECRET"])
        if client.select(mailbox, readonly=True)[0] != "OK":
            raise RuntimeError("Unable to open INBOX")
        validity = client.response("UIDVALIDITY")[1][0].decode()
        next_uid = int(client.response("UIDNEXT")[1][0])
        db.execute("""CREATE TABLE IF NOT EXISTS inbox_cursor(
            mailbox TEXT, validity TEXT, uid INTEGER, PRIMARY KEY(mailbox, validity))""")
        cursor = db.execute("SELECT uid FROM inbox_cursor WHERE mailbox=? AND validity=?",
                            (account, validity)).fetchone()
        if cursor:
            start = cursor[0]
        else:
            # Include replies received since the first campaign send.
            first = db.execute("SELECT min(day) FROM deliveries").fetchone()[0]
            if first:
                date = datetime.fromisoformat(first).strftime("%d-%b-%Y")
                status, matches = client.uid("SEARCH", None, "SINCE", date)
                if status != "OK":
                    raise RuntimeError("Unable to locate campaign replies")
                start = min((int(uid) for uid in matches[0].split()), default=next_uid)
            else:
                start = next_uid
        if start < next_uid:
            status, data = client.uid("SEARCH", None, "UID", f"{start}:{next_uid - 1}")
            if status != "OK":
                raise RuntimeError("Unable to search inbox")
            for uid in data[0].split():
                status, parts = client.uid("FETCH", uid, "(BODY.PEEK[])")
                if status != "OK":
                    raise RuntimeError(f"Unable to fetch inbox message {uid.decode()}")
                raw = next((part[1] for part in parts if isinstance(part, tuple)), None)
                if raw is not None:
                    record_reply(db, config, account, validity, uid.decode(), raw)
        db.execute("INSERT OR REPLACE INTO inbox_cursor VALUES(?,?,?)", (account, validity, next_uid))
        db.commit()


def forward_pending(db, config):
    for reply in db.execute("SELECT rowid,* FROM replies WHERE forwarding='pending'").fetchall():
        body = f"Campaign: {reply['campaign']}\nFrom: {reply['sender']}\n\n{reply['body']}"
        message = message_for(config, reply["destination"], f"Interested: {reply['subject']}", body,
                              make_msgid(domain=config["from"].split("@")[1]))
        message["Reply-To"] = address(reply["sender"])
        claimed = db.execute(
            "UPDATE replies SET forwarding='attempted' WHERE rowid=? AND forwarding='pending'",
            (reply["rowid"],),
        ).rowcount
        db.commit()
        if not claimed:
            continue
        smtp_send(config, message)
        db.execute("UPDATE replies SET forwarding='forwarded' WHERE rowid=?", (reply["rowid"],))
        db.commit()


def cycle(db, config, live):
    if live:
        scan_inbox(db, config)
        forward_pending(db, config)
    send_campaigns(db, config, live)


def show(rows):
    for row in rows:
        print(json.dumps(dict(row), ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--db", default="leadnclose.sqlite3")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("discover", "leads", "replies", "deliveries", "microsoft-login"):
        commands.add_parser(name)
    for name in ("approve", "suppress"):
        commands.add_parser(name).add_argument("ids", type=int, nargs="+")
    for name in ("send", "run"):
        sub = commands.add_parser(name)
        sub.add_argument("--live", action="store_true")
    args = parser.parse_args()
    with contextlib.closing(sqlite3.connect(args.db)) as db:
        db.row_factory = sqlite3.Row
        db.executescript(SCHEMA)
        if args.command in ("leads", "replies", "deliveries"):
            show(db.execute("SELECT * FROM " + args.command + " ORDER BY rowid DESC"))
            return
        if args.command in ("approve", "suppress"):
            column = "approved" if args.command == "approve" else "suppressed"
            db.executemany(f"UPDATE leads SET {column}=1 WHERE id=?", [(key,) for key in args.ids])
            db.commit()
            return
        config = json.loads(Path(args.config).read_text(encoding="utf-8"))
        if args.command == "microsoft-login":
            microsoft_token(config, interactive=True)
            print("Microsoft mailbox authorized.")
        elif args.command == "discover":
            discover(db, config)
        elif args.command == "send":
            cycle(db, config, args.live)
        else:
            next_discovery = 0
            while True:
                try:
                    if time.monotonic() >= next_discovery:
                        discover(db, config)
                        next_discovery = time.monotonic() + 3600 * float(config.get("discovery_hours", 24))
                    cycle(db, config, args.live)
                except (OSError, imaplib.IMAP4.error, RuntimeError) as error:
                    print(f"Worker will retry the next cycle: {error}", flush=True)
                time.sleep(max(15, int(config.get("poll_seconds", 120))))


if __name__ == "__main__":
    main()
