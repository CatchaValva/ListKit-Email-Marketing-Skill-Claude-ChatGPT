---
name: leadnclose-ai
description: Set up and operate the LeadnClose AI outreach worker for finding public business contact emails, preparing and previewing campaigns, and routing interested replies to another inbox.
---

# LeadnClose AI

Use the bundled [operator guide](README.md) for installation, configuration and commands. The worker runs on the user's computer or server, where it can reach the configured email provider. Help the user configure that host. A Claude chat session does not host the continuous worker.

- Use [config.example.json](config.example.json) as the configuration template. Ask for the business type, location or known websites, campaign copy and forwarding inbox when they are needed. Keep mailbox credentials and token caches on the user's host.
- Use [leadnclose.py](leadnclose.py) for discovery and campaign operations. Report the contact source and domain-mail status. A domain MX record does not confirm that the individual mailbox exists.
- Show the operator how to approve the selected lead IDs, add them to a campaign and preview with `send`. When asked to start live automation, use the operator's configured host and the documented `run --live` command. The worker polls for campaign replies while it is running.
- To troubleshoot, inspect the relevant command output and the delivery or reply records. Use `python -m unittest -v` for an offline test of the bundled worker.
