import sqlite3
import unittest
from email.message import EmailMessage
from unittest.mock import patch

import leadnclose as app


class WorkflowTest(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.addCleanup(self.db.close)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(app.SCHEMA)
        self.config = {
            "from": "outreach@example.com", "forward_to": "sales@example.com",
            "sender_identity": "Move2Virtual", "postal_address": "123 Example Street",
            "daily_limit": 1,
            "campaigns": [{"id": "intro", "enabled": True, "lead_ids": [2],
                           "subject": "Hello {{company}}", "body": "Interested?"}],
            "websites": ["https://clinic.example"],
        }

    def test_discovery_send_and_route(self):
        page = '<a href="mailto:hello@clinic.example">Contact</a> owner@clinic.example info@clinic.example'
        with patch.object(app, "fetch", return_value=page), patch.object(app, "mx_status", return_value="domain-mx"):
            app.discover(self.db, self.config)
            app.discover(self.db, self.config)
        self.assertEqual(self.db.execute("SELECT count(*) FROM leads").fetchone()[0], 2)
        with patch.object(app, "smtp_send") as smtp:
            app.send_campaigns(self.db, self.config, True)
            smtp.assert_not_called()
            self.db.execute("UPDATE leads SET approved=1")
            self.db.commit()
            app.send_campaigns(self.db, self.config)
            smtp.assert_not_called()
            app.send_campaigns(self.db, self.config, True)
            app.send_campaigns(self.db, self.config, True)
            smtp.assert_called_once()
            sent = smtp.call_args.args[1]
            self.assertEqual(str(sent["To"]), "info@clinic.example")
            self.assertEqual(str(sent["Subject"]), "Hello clinic.example")

            reply = EmailMessage()
            reply["From"] = sent["To"]
            reply["In-Reply-To"] = sent["Message-ID"]
            reply["Subject"] = "Re: Hello"
            reply.set_content("Yes!\n\n> Reply unsubscribe to stop")
            for uid in ("1", "1"):
                app.record_reply(self.db, self.config, "INBOX", "1", uid, reply.as_bytes())
            app.forward_pending(self.db, self.config)
            app.forward_pending(self.db, self.config)
            self.assertEqual(smtp.call_count, 2)
            self.assertEqual(str(smtp.call_args.args[1]["To"]), "sales@example.com")
            self.assertEqual(str(smtp.call_args.args[1]["Reply-To"]), "info@clinic.example")

            reply.set_content("Unsubscribe")
            app.record_reply(self.db, self.config, "INBOX", "1", "2", reply.as_bytes())
            self.assertEqual(self.db.execute("SELECT suppressed FROM leads WHERE id=2").fetchone()[0], 1)

    def test_classifier(self):
        reply = EmailMessage()
        reply.set_content("No thanks, I am not interested.")
        self.assertEqual(app.classify(reply, app.extract_reply(reply)), "negative")
        self.assertEqual(app.classify(reply, "Thanks for the email."), "review")
        reply["Auto-Submitted"] = "auto-replied"
        self.assertEqual(app.classify(reply, "Yes"), "automatic")


if __name__ == "__main__":
    unittest.main()
